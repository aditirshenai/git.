function setup() {
  createCanvas(1400, 400);
  
}

function draw() {
  background(82,86,89);
      
}
function preload (){
if (keyCode === 32){
    background (255);
  }

}